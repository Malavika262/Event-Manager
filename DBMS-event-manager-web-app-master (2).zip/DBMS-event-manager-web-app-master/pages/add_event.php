<?php
session_start();
$event_name = '';
$event_description = '';
$event_poster = '';
$event_schedule = '';
$event_mode = '';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// connect to mysql database
try{
    $connect = mysqli_connect("localhost","root","","nitc events");
} catch (mysqli_sql_exception $ex) {
    echo 'Error';
}

// get values from the form
function getPosts()
{
    $posts = array();
    $posts[0] = $_POST['event_name'];
    $posts[1] = $_POST['event_desc'];
    $posts[2]=$_FILES['poster']['tmp_name'];
	$posts[3] = $_POST['event_schedule'];
    return $posts;
}

if(isset($_POST['Online']))
{
    $data = getPosts();
    $org_mail_id=$_GET['org_mail_id'];
    $data[4] = 'online';
   $image = file_get_contents($data[2]);
   $_stmt = $connect->prepare("INSERT INTO events(event_name,event_description,event_poster,event_schedule,event_mode,organisation_mail_id) VALUES(?,?,?,?,?,?)");
   $_stmt->bind_param("ssbsss", $data[0],$data[1],$_null,$data[3],$data[4],$org_mail_id);
   $_stmt->send_long_data(2,$image);

    //$insert_Query = "INSERT INTO events(event_name,event_description,event_poster,event_schedule,event_mode,organisation_mail_id) VALUES ('$data[0]','$data[1]','$image','$data[3]','$data[4]','$org_mail_id')";
    try{
        //$insert_Result = mysqli_query($connect, $insert_Query);
        if($_stmt->execute())
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                echo 'Data Inserted';
				if(isset($_POST['Online'])){
      header("Location:http://localhost/demo/pages/if_online.php? event_name='$data[0]'&org_mail_id=$org_mail_id");
				}
            }else{
                echo 'Data Not Inserted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Insert '.$ex->getMessage();
    }

}
elseif(isset($_POST['Offline']))
{
    $data = getPosts();
    $org_mail_id=$_GET['org_mail_id'];
    $data[4] = 'offline';
    $image = file_get_contents($data[2]);
    $_stmt = $connect->prepare("INSERT INTO events(event_name,event_description,event_poster,event_schedule,event_mode,organisation_mail_id) VALUES(?,?,?,?,?,?)");
    $_stmt->bind_param("ssbsss", $data[0],$data[1],$_null,$data[3],$data[4],$org_mail_id);
    $_stmt->send_long_data(2,$image);
    try{
        if($_stmt->execute())
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                echo 'Data Inserted';
				            if(isset($_POST['Offline'])){
                      header("Location:http://localhost/demo/pages/if_offline.php? event_name='$data[0]'&org_mail_id=$org_mail_id");
				}
            }else{
                echo 'Data Not Inserted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Insert '.$ex->getMessage();
    }

}

?>

<!DOCTYPE Html>
<html>
    <head>
        <title>EVENT MANAGER</title>

		<meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
      <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
      <link rel="stylesheet" href="events_page.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <!---jQuery library --->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
     </script>
	 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
h1 {
	text-align: center;
	color: white;
}
</style>
    </head>
    <body>
	<div class="add-box">
	<h1>UPLOAD EVENT</h1>
	<div class="container">
        <form class="add-event" method="post" enctype="multipart/form-data">

			<div class="form-group col-md-7">
			<label for="Name">Event Name</label>
            <input type="text" name="event_name" id="Name" class="form-control" placeholder="Event Name" value="<?php echo $event_name;?>" required><br><br>
			</div>


			 <div class="form-group col-md-7">
               <label for="Textarea">Event Description</label>
               <textarea class="form-control" name="event_desc" id="Textarea" rows="4" value="<?php echo $event_description;?>" required></textarea>
             </div>


			<div class="form-group col-md-7">
               <label for="FormControlFile">Event Poster</label>
               <input type="file" class="form-control-file" name="poster" id="FormControlFile" value="<?php echo $event_poster;?>" required>
            </div>


			<div class="form-group col-md-7">
			<label for="Schedule">Event Schedule</label>
			<input type="text" name="event_schedule" class="form-control" id="Schedule" placeholder="Event Schedule" value="<?php echo $event_schedule;?>" required><br><br>
			</div>


			<div class="col-sm-6">
              <label for="Mode">Event Mode</label>
			  <input type="submit" class="btn btn-primary form-control"  name="Online" value="Online"><br>
					<br>
					<input type="submit" class="btn btn-primary form-control"  name="Offline" value="Offline"><br>
					<br>
              </div>



        </form>
		</div>
    </body>
</html>
