<?php
  $connection = mysqli_connect("localhost","root","","nitc events");
  $approve = $_POST['status'];
  if($approve=="true"){
      $query = "UPDATE organisation SET verification_status='approved' WHERE organisation_mail_id=(?)";
  }
  else {
    $query = "UPDATE organisation SET verification_status='rejected' WHERE organisation_mail_id=(?)";
  }
  $stmt = $connection->prepare($query);
  $stmt->bind_param("s",$_POST["org_mail"]);
  if(!$stmt->execute()){
    echo "failed to change database values";
  }else {
    if($approve=="true"){
        echo "<p>Approved</p>";
    }
    else {
      echo "<p>Rejected</p>";
    }
  }
  $connection->close();
  //mysqli_close($connection);
  ?>
