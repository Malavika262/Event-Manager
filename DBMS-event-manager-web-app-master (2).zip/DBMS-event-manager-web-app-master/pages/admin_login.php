<?php
session_start();
$er='';
    if(isset($_POST['login'])){
	  $admin_id=$_POST['admin_id'];
      $pass= $_POST['password'];
      $connection=new mysqli('localhost','root','','nitc events');
        if(!($connection)){
        die('connection error');
      }
		$result = mysqli_query($connection,"SELECT * FROM admins WHERE admin_mail_id='$admin_id'");
		$arr=mysqli_fetch_array($result);
        if($arr && $arr['admin_password']==$pass){
			$_SESSION['arr'] = $arr;
		  	echo 'done!!';
        header("Location:http://localhost/demo/pages/admin_page.php");
        }
        else{
          $er = "Invalid Login..Please enter the correct details..";
        }

    }
	if(isset($_POST['alter'])){
      header("Location:http://localhost/demo/pages/login.php");
  }
	if(isset($_POST['alter2'])){
		header("Location:http://localhost/demo/pages/org_login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
      <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

      <link rel="stylesheet" href="style.css">
	<title>Login Page</title>
</head>
<body>
	<div class="container">
		<div class="row col-lg-6 col-md-12 col-sm-12 col-12 login-content">
		<form action="admin_login.php" autocomplete="off" method="POST">
			<div class="header-area">
			<div class="navbar-area">

				      <nav class="site-navbar">
				        <ul>
				          <li><a href="main_page.php">HOME</a></li>
				        </ul>

				        <button class="nav-toggler">
				          <span></span>
				        </button>
				      </nav>

				  </div>
			</div>

        	<div class="col-lg-10 offset-lg-2 col-md-10 offset-md-1 col-sm-12 offset-sm-2 col-12 login-form">
        		<h4>ADMIN LOGIN</h4>
	        	<div class="form-group">
	        		<input type="text" class="form-control " name="admin_id" placeholder="ADMIN ID">
	        	</div>
				<br>
	        	<div class="form-group">
	        		<input type="password" class="form-control" name="password"  placeholder="Password">
				</div>
				<br>
				<small class="error" style="color:red">
				<?php
          		if($er)
            	echo $er;
				?></small>
				<br>

	        	<div class="form-group col-lg-8 offset-lg-2 col-md-6 offset-md-3 col-sm-6 offset-sm-3 login-btn">
					<input type="submit" class="btn btn-primary form-control"  name="login" value="Login"><br>
					<br>
					<input type="submit" class="btn btn-primary form-control"  name="alter" value="Login as User"><br>
					<br>
					<input type="submit" class="btn btn-primary form-control"  name="alter2" value="Login as Organisation"><br>
	        	</div>


        	</div>

        </div>
	</div>
	<script type="text/javascript" src="js/login.js"></script>
</body>
</html>
