<?php
  $connection = mysqli_connect("localhost","root","","nitc events");
  if(!$connection){
    die("connection failed: " . $connection->connect_error);
  }
  $query = "SELECT organisation_name,organisation_mail_id,organisation_head,head_mail_id,verification_status FROM organisation WHERE verification_status='not verified'";
  $result=mysqli_query($connection,$query);
  $org_array = $result->fetch_all();
  //var_dump($org_array);
  //mysqli_close($connection);
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!---jQuery library --->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <!---Popper JS --->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <!--Latest compiled Javascript--->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
    </script>
    <script type="text/javascript">
    function approve(id,org_name,org_mail){
      const xhr = new XMLHttpRequest();
      xhr.open("POST","admin_db.php");
      xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
      if(confirm(`Are you sure want to approve the ${org_name} application?`)){
          xhr.send(`org_mail=${org_mail}&status=true`);
          xhr.onload = function(){
            const status = document.getElementById(`status_${id}`);
            status.innerHTML = this.responseText;
          }
      }
    }
    function reject(id,org_name,org_mail){
      const xhr1 = new XMLHttpRequest();
      xhr1.open("POST","admin_db.php");
      xhr1.setRequestHeader("Content-type","application/x-www-form-urlencoded");
      if(confirm(`Are you sure want to reject the ${org_name} application?`)){
        xhr1.send(`org_mail=${org_mail}&status=false`);
        xhr1.onload = function(){
          const status = document.getElementById(`status_${id}`);
          status.innerHTML = this.responseText;
        }
      }
    }
    </script>
    <title>admin page</title>
  </head>
  <body>
    <div class="navbar-area" style="float:right; margin:10px;">
      <nav class="site-navbar">
             <ul>
               <form action="login.php">
    <input type="submit" value="Logout" />
</form>
             </ul>
           </nav>

       </div>
      <table class="table table-hover table-dark">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Organisation name</th>
            <th scope="col">Organisation Head name</th>
            <th scope="col">Organisation mail id</th>
            <th scope="col">Organisation head mail id</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php $temp=0; while($temp<$result->num_rows){?>
            <form id="form_<?php echo $temp?>"  method="post">
              <tr>
                <th scope="row"><?php echo ($temp+1) ?></th>
                <td><?php echo $org_array[$temp][0] ?></td>
                <td><?php echo $org_array[$temp][1] ?></td>
                <td><?php echo $org_array[$temp][3] ?></td>
                <td><?php echo $org_array[$temp][2] ?></td>
                <td id="status_<?php echo $temp?>"><?php echo $org_array[$temp][4]?></td>
                <td><button id="<?php echo $temp?>" type="button" onclick="approve(this.id,'<?php echo $org_array[$temp][0]?>','<?php echo $org_array[$temp][1] ?>');" class="btn btn-success">Approve</button></td>
                <td><button type="button" id="<?php echo $temp?>" class="btn btn-danger" onclick="reject(this.id,'<?php echo $org_array[$temp][0]?>','<?php echo $org_array[$temp][1] ?>');">Reject</button></td>
              </tr>
            </form>
          <?php $temp=$temp+1;}?>
        </tbody>
      </table>
  </body>
</html>
