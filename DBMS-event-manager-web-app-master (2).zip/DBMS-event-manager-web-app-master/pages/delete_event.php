<?php
$event_id = "";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// connect to mysql database
try{
    $connect = mysqli_connect("localhost","root","","nitc events");
} catch (mysqli_sql_exception $ex) {
    echo 'Error';
}

// get values from the form
function getPosts()
{
    $posts = array();
    $posts[0] = $_POST['event_id'];
    return $posts;
}


// Delete
if(isset($_POST['delete']))
{
    $org_mail_id = $_GET['org_mail_id'];
    $data = getPosts();
    $delete_Query = "DELETE FROM events WHERE event_id ='$data[0]' AND organisation_mail_id='$org_mail_id'";

    try{
        $delete_Result = mysqli_query($connect, $delete_Query);

        if($delete_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {
              $query = "DELETE FROM online_event WHERE online_event_id ='$data[0]'";
              $delete_result = mysqli_query($connect,$query);
              $query = "DELETE FROM offline_event WHERE offline_event_id ='$data[0]'";
              $delete_result = mysqli_query($connect,$query);
              header("Location:http://localhost/demo/pages/view_uploaded_events.php?org_mail_id=$org_mail_id");
            }else{
                echo "Error deleting the event";
            }
        }
    } catch (Exception $ex) {
        echo 'Error Deleting the event ';
    }
}





?>

<!DOCTYPE Html>
<html>
    <head>
        <title>EVENT MANAGER</title>
		<link rel="stylesheet" href="starter-template.css">
		<link rel="stylesheet" href="starter-template.css">
		<meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
      <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
      <link rel="stylesheet" href="events_page.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <!---jQuery library --->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
     </script>
	 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
h1 {
	margin-top: 10px;
	text-align: center;
}
</style>
   </head>
    <body>
	<div class="delete-box">
	<h1>DELETE EVENT</h1>
	<div class="container">
        <form class="delete-event" action="http://localhost/demo/pages/delete_event.php?org_mail_id=<?php echo $_GET['org_mail_id'] ?>" method="post">

		<div class="form-group col-md-7">
			<label for="eventID">Event ID</label>
            <input type="text" name="event_id" id="eventID" class="form-control" placeholder="Event ID" value="<?php echo $event_id;?>" required><br><br>
			</div>


			<div class="col-sm-10">
                <input type="submit" name="delete" value="Delete" class="op">
          </div>
        </form>
		</div>
    </body>
</html>
