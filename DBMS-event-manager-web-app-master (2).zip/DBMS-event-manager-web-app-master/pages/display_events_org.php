<?php
$org_mail_id = $_GET['org_mail_id'];
$connection = mysqli_connect("localhost","root","","nitc events");
if(!$connection){
  die("connection failed: " .$connection->connect_error);
}
$query_org = "SELECT organisation_mail_id,organisation_name FROM organisation WHERE 1";
$result_org=mysqli_query($connection,$query_org);
$org = $result_org->fetch_all();
?>

<!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
   <style>
        .site-navbar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}

.site-navbar ul {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
}
.site-navbar ul li a {

    color: white !important;
    padding: 20px;
    padding-right: 10px;
    display: block;
    text-decoration: none;
    text-transform: uppercase;
    font-weight: bold;
    margin-top: 16px;

}

.nav-toggler {
  border: none;
  padding: 5px;
  background-color: white;
  cursor: pointer;
  height: 39px;
  display: none;
}
.nav-toggler:focus {
  border: none;
  outline: none;
}

.nav-toggler span,
.nav-toggler span:before,
.nav-toggler span:after {
  width: 28px;
  height: 3px;
  background-color: white;
  display: block;
  transition: .3s;
}
.nav-toggler span:before {
  content: '';
  transform: translateY(-9px);
}
.nav-toggler span:after {
  content: '';
  transform: translateY(6px);
}
.nav-toggler.toggler-open span {
  background-color: transparent;
}
.nav-toggler.toggler-open span:before {
  transform: translateY(0px) rotate(45deg);
}
.nav-toggler.toggler-open span:after {
  transform: translateY(-3px) rotate(-45deg);
}
}
  </style>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
      <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
      <link rel="stylesheet" href="events_page.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <!---jQuery library --->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
     </script>
     <!---Popper JS --->
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
     </script>
     <!--Latest compiled Javascript--->
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
     </script>
     <title>Events</title>
   </head>
   <body>
   <div class="navbar-area">

          <nav class="site-navbar">
            <ul>
              <li><a href="http://localhost/demo/pages/display_events_org.php?org_mail_id=<?php echo $org_mail_id ?>">HOME</a></li>
              <li><a href="http://localhost/demo/pages/add_event.php?org_mail_id=<?php echo $org_mail_id ?>">UPLOAD EVENTS</a></li>
              <li><a href="http://localhost/demo/pages/view_uploaded_events.php?org_mail_id=<?php echo $org_mail_id ?>">VIEW UPLOADED EVENTS</a></li>
              <li><a href="login.php">LOGOUT</a></li>
              <li><a href="#"></a></li>
              <li><a href="#"></a></li>
            </ul>
          </nav>

      </div>
     <?php $temp=0; while($temp<$result_org->num_rows){
           $org_mail_id = $org[$temp][0];
           $query = "SELECT event_id,event_name,event_poster,event_schedule,event_mode FROM events WHERE organisation_mail_id='$org_mail_id'";
           $result=mysqli_query($connection,$query);
           if(!$result){
             $temp = $temp+1;
             continue;
           }
           $events = $result->fetch_all();
           $temp2=0;
           $org_name = strtoupper($org[$temp][1]);
           if($result->num_rows>0){
             echo("<h3 class='pl-3 pt-2' style='color:white'>$org_name</h3>");
           }?>
           <div class="row">
             <?php while($temp2<$result->num_rows){
             ?>
             <div class="p-3">
                 <div class="card rounded" style="width: 18rem;">
                   <?php echo '<img style="width:18rem;height:15rem;" class="card-img-top p-0 m-0" src="data:image/jpeg;base64,'.base64_encode($events[$temp2][2] ).'"/>' ?>
                   <div class="card-body">
                     <h4 style="color:white"><?php echo  $events[$temp2][1]?></h4>
                     <p class="card-text" style="color:white"><?php echo  $events[$temp2][3] ?></p>
                     <p class="card-text" style="color:white">
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
    <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
  </svg> <?php if($events[$temp2][4]=="offline"){
    $id = $events[$temp2][0];
    $query = "SELECT venue FROM offline_event WHERE offline_event_id='$id'";
    $result1=mysqli_query($connection,$query);
    $offline_event_info = $result1->fetch_all();
    echo $offline_event_info[0][0];
  } else{
    echo "online"; } ?></p>
                     <a href="event_info.php?id=<?php echo $events[$temp2][0]?>" class="stretched-link"></a>
                   </div>
                 </div>
             </div>
           <?php $temp2=$temp2+1;}?>
           </div>
          <?php $temp=$temp+1;}?>
   </body>
 </html>
