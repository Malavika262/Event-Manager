<?php
  $id = $_GET["id"];
  $connection = mysqli_connect("localhost","root","","nitc events");
  if(!$connection){
    die("connection failed: " .$connection->connect_error);
  }
  $query = "SELECT * FROM events WHERE event_id='$id'";
  $result=mysqli_query($connection,$query);
  $event_info = $result->fetch_all();
 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
      <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
      <link rel="stylesheet" href="event_info_style.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <!---jQuery library --->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
     </script>
     <!---Popper JS --->
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
     </script>
     <!--Latest compiled Javascript--->
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
     </script>
     <title>Events information</title>
   </head>
   <body>
     <br><br>
     <?php echo '<img class="center" style=" display: block;margin-left: auto; margin-right: auto;border-radius: 2% height: 300 ;width: 400;" src="data:image/jpeg;base64,'.base64_encode($event_info[0][3] ).'"/>' ?>
     <h3 style="color:blue">  <?php echo $event_info[0][1] ?></h3>
     <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 12 12">
<path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z"/>
</svg> <?php
if($event_info[0][6]=="offline"){
  $query = "SELECT * FROM offline_event WHERE offline_event_id='$id'";
  $result1=mysqli_query($connection,$query);
  $offline_event_info = $result1->fetch_all();
  $place = $offline_event_info[0][1];
  echo($place);
} else{
  $query = "SELECT * FROM online_event WHERE online_event_id='$id'";
  $result2=mysqli_query($connection,$query);
  $online_event_info = $result2->fetch_all();
  echo  $event_info[0][6]; }?></p>
      <h5>EVENT TIMINGS:</h5>
      <p><?php echo  $event_info[0][4] ?></p>
      <h5>EVENT DESCRIPTION:</h5>
     <p> <?php echo $event_info[0][2] ?></p>
     <?php
        if($event_info[0][6]=="online"){
          if($online_event_info[0][2]){
            echo "<h5>MEET LINK</h5>";
            $temp = $online_event_info[0][2];
            echo "<p>$temp</p>";
          }
          if($online_event_info[0][4]){
            echo "<h5>MEET PASSWORD</h5>";
            $temp = $online_event_info[0][4];
            echo "<p>$temp</p>";
          }
          if($online_event_info[0][1]){
            echo "<h5>MEET ID</h5>";
            $temp = $online_event_info[0][1];
            echo "<p>$temp</p>";
          }
          if($online_event_info[0][3]){
            echo "<h5>REGISTRATION LINK</h5>";
            $temp = $online_event_info[0][3];
            echo "<p>$temp</p>";
          }
        }else{
          if($offline_event_info[0][2]){
            echo "<h5>REGISTRATION PROCEDURE</h5>";
            $temp = $offline_event_info[0][2];
            echo "<p>$temp</p>";
          }
        }
      ?>
     <h5>CONTACT FOR QUERIES:</h5>
     <p><?php echo $event_info[0][5] ?></p>
   </body>
 </html>
