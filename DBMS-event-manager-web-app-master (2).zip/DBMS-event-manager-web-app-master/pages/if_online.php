<?php
session_start();
$meet_link = "";
$meet_password = "";
$reg_link = "";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// connect to mysql database
try{
    $connect = mysqli_connect("localhost","root","","nitc events");
} catch (mysqli_sql_exception $ex) {
    echo 'Error';
}

// get values from the form
function getPosts()
{
    $posts = array();
    $posts[0] = $_POST['meet_link'];
    $posts[1] = $_POST['reg_link'];
    $posts[2] = $_POST['meet_password'];
	return $posts;
}


// Insert
if(isset($_POST['insert']))
{
   $event_name = $_GET['event_name'];
   $org_mail_id =$_GET['org_mail_id'];
    $data = getPosts();
    $get_event_id = "SELECT event_id FROM events WHERE event_name= $event_name AND organisation_mail_id='$org_mail_id'";
    $event_id_result = mysqli_query($connect,$get_event_id);
    $event_id_info = $event_id_result->fetch_all();
    $event_id = $event_id_info[0][0];
    $insert_Query = "INSERT INTO online_event values ($event_id,'none','$data[0]','$data[1]','$data[2]')";
    try{
        $insert_Result = mysqli_query($connect, $insert_Query);

        if($insert_Result)
        {
            if(mysqli_affected_rows($connect) > 0)
            {
                echo 'Data Inserted';
                header("Location:http://localhost/demo/pages/display_events_org.php?org_mail_id=$org_mail_id");

            }else{
                echo 'Data Not Inserted';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Insert '.$ex->getMessage();
    }
}

?>


<!DOCTYPE Html>
<html>
    <head>
        <title>EVENT MANAGER</title>

		<meta charset="utf-8">
     <meta name="viewport" content="width=device-width,initial-scale=1">
      <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
      <link rel="stylesheet" href="events_page.css">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
     <!---jQuery library --->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
     </script>
	 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
h1 {
	text-align: center;
	color: white;
}
</style>
    </head>
    <body>
	<div class="add-box">
	<h1>ONLINE EVENT DETAILS</h1>
	<div class="container">
        <form class="add-event" action ="http://localhost/demo/pages/if_online.php? event_name=<?php echo $_GET['event_name'] ?>&org_mail_id=<?php echo $_GET['org_mail_id'] ?>" method="post">

		    <div class="form-group col-md-7">
			<label for="Name">Meet Link</label>
            <input type="text" name="meet_link" id="meet_link" class="form-control" placeholder="Meet Link" value="<?php echo $meet_link;?>" required><br><br>
			</div>


			<div class="form-group col-md-7">
			<label for="Name">Registration Link(if any)</label>
            <input type="text" name="reg_link" id="reg_link" class="form-control" placeholder="Registration Link" value="<?php echo $reg_link;?>"><br><br>
			</div>

			<div class="form-group col-md-7">
			<label for="Name">Meet Password(if any)</label>
            <input type="text" name="meet_password" id="meet_password" class="form-control" placeholder="Meet Password" value="<?php echo $meet_password;?>"><br><br>
			</div>


			<div class="col-sm-10">
      <button type="submit" name="insert" value="Upload" class="btn btn-primary">Upload</button>
    </div>

        </form>
		</div>
    </body>
</html>
