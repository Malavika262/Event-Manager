<?php
session_start();
$er='';
    if(isset($_POST['login'])){
        header("Location:http://localhost/pages/login.php");
    }
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Pure CSS Landing Page Design</title>
		<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<link rel="stylesheet" href="home.css">
	</head>
	<body>
		<div class="open">
			<div class="layer"></div>
			<div class="layer"></div>
		</div>
		<section>
			<div class="header">

				<ul>
					<li>
						<a href="#">About</a>
					</li>


				</ul>
			</div>
			<div class="bannerText">
				<h2>Event Manager</h2><br>
				<h3>Get started</h3>
    <p>
		<a href="login.php" value="login" name="login">Login</a>
    </p>

        <h3>Haven't created an account already?</h3>
        <a href="signuppage.html">Signup</a>
			</div>
			<ul class="sci">
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter"></i></a></li>
				<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram"></i></a></li>
			</ul>
			<div class="element1"></div>
			<div class="element2"></div>
		</section>
	</body>
</html>
