<?php
  $hashed_password = sha1($_POST["password"]);
  $connection = mysqli_connect("localhost","root","","nitc events");
  if(!$connection){
    die("connection failed: " . $connection->connect_error);
  }
  $query = "INSERT INTO users VALUES (?,?,?,?,0)";
  $stmt = $connection->prepare($query);
  $stmt->bind_param("ssss",$_POST['email'],$hashed_password,$_POST['firstname'],$_POST['lastname']);
  if($stmt->execute()){
    echo("success");
    header("Location:http://localhost/demo/pages/display_events.php");
  }else{
    echo("Sign up failed");
  }
  $connection->close();
 ?>
