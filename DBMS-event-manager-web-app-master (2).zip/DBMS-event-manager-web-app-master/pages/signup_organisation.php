<?php
  $hashed_password = sha1($_POST["password"]);
  $connection = mysqli_connect("localhost","root","","nitc events");
  if(!$connection){
    die("connection failed: " . $connection->connect_error);
  }
  $query = "INSERT INTO organisation(organisation_mail_id,organisation_name,organisation_head,head_mail_id,organisation_encrypted_password) VALUES (?,?,?,?,?)";
  $stmt = $connection->prepare($query);
  $stmt->bind_param("sssss",$_POST['email'],$_POST['organisation_name'],$_POST['organisation_head_name'],$_POST['organisation_head_mail_id'],$hashed_password);
  if($stmt->execute()){
    echo('
    <div class="alert alert-success" role="alert">
      Thankyou for signing up! Admins would soon verify your account and a mail would be sent once the verification process gets over. <a href="main_page.php">HOME</a>
      </div');
  }else{
    echo('
    <div class="alert alert-danger" role="alert">
      Failed to create an account!
    </div>
    ');
  }
  $connection->close();
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!---jQuery library --->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <!---Popper JS --->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
    </script>
    <!--Latest compiled Javascript--->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
    </script>
    <title>organisation</title>
  </head>
  <body>

  </body>
</html>
