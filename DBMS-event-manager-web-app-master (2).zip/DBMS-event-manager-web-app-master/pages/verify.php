<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php
    if(isset($_GET['email'])&&!empty($_GET['email'])&&isset($_GET['hash'])&&!empty($_GET['hash'])){
      $connection = mysqli_connect("localhost","root","","nitc events");
      if(!connection){
        die("Connection failed" .$connection->connect_error);
      }
      $query = "UPDATE users SET user_verified = 1 WHERE user_mail_id=?";
      $stmt = $connection->prepare($query);
      $stmt->bind_param("s",$_GET['email']);
      if($stmt->execute()){
        echo('verification success');
        echo('login to your account and enjoy our services');
      }
      echo('verification failed, try again');
      $connection->close();
    }
  ?>
  <head>
    <meta charset="utf-8">
    <title>verification</title>
  </head>
  <body>
  </body>
</html>
